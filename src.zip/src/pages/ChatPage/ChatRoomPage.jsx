import React from "react";
import ChatRoomPersonal from "../../components/ChatPage/ChatRoomPersonal/ChatRoomPersonal.jsx";

const ChatRoomPage = () => <ChatRoomPersonal />;

export default ChatRoomPage;
