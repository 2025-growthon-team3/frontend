import React from "react";
import TabBar from "../../components/TabBar/TabBar";

const LocationPage = () => {
  return (
    <div>
      <TabBar type="songil" index={0} />
    </div>
  );
};

export default LocationPage;
