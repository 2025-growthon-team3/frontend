import React from "react";
import TabBar from "../../components/TabBar/TabBar";

const MyPage = () => {
  return (
    <div>
      <TabBar type="songil" index={2} />
    </div>
  );
};

export default MyPage;
