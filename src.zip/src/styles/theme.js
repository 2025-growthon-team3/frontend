const theme = {
  sizes: {
    width: "393px",
    height: "852px",
  },
  colors: {
    orange: "#FFA622",
    lightorange: "#FFF4E4",
    lightorange78: "rgba(255, 244, 228, 0.78)",
    mint: "#4BC7B9",
    lightmint: "#CCEFEB",
  },
};

export default theme;
